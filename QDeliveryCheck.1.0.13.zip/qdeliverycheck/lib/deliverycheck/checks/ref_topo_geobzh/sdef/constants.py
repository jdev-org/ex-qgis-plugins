import os.path
from .constants_load import ReferentielGeobretagneShapefileConfig

current_dir = os.path.dirname(os.path.abspath(__file__))

shp_csv = os.path.join(current_dir,
                       'definitions/OBJETS_SHP_COMMUN.csv')

dxf_csv = os.path.join(current_dir,
                       '../commun/definitions/OBJETS_DXF_COMMUN.csv')

socle_commun_shapefile_config = ReferentielGeobretagneShapefileConfig(shp_csv,
                                                                      dxf_csv)
