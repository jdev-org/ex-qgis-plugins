from osgeo import ogr
from deliverycheck.util.formats.ogr import get_points_from_geometry
import ezdxf
from ezdxf.blkrefs import BlockDefinitionIndex
from ezdxf import zoom
import os.path

current_dir = os.path.dirname(os.path.abspath(__file__))

DXF_TEMPLATE = os.path.join(current_dir, 'definitions/socle_commun+LA.dxf')

AFFLEURANT_LAYERS = ('PCRS_AFFLEURANT_E', 'PCRS_AFFLEURANT_P', )

AFFLEURANT_OBJECT_TYPE_MAPPING = {
    'PCRS_AFFLEURANT_E': 'Polyligne',
    'PCRS_AFFLEURANT_P': 'Point'
}

AFFLEURANT_CALQUE_MAPPING = {
    'ASSAEU': 'EAUUS_SCS',
    'ASSARU': 'UNITA_SCS',
    'ASSA': 'EAUUS_SCS',
    'AEP': 'EAUPO_SCS',
    'ELECECL': 'ECPUB_SCS',
    'ELEC': 'ELECT_SCS',
    'GAZ': 'GAZFL_SCS',
    'MULT': 'INDET_SCS',
    'ELECSLT': 'SIGNV_SCS',
    'COM': 'TELEC_SCS',
    'ASSAEP': 'EAUPL_SCS',
    'INCE': 'EAUPO_SCS',
    'CHAU': 'CHAUF_SCS',
    'DECH': '',
    'CHIM': '',
    '00': 'INDET_SCS'
}


def convert_gpkg_to_dxf(input_gpkg_path,
                        dxf_filename,
                        dxf_calques_objets,
                        logger,
                        check_name
                        ):
    # Open GPKG
    logger.info(check_name, 'Ouverture du fichier GPKG à convertir')
    gpkg_ds = ogr.Open(input_gpkg_path)
    num_gpkg_layers = gpkg_ds.GetLayerCount()

    # Create DXF file from template
    dxf_doc = ezdxf.readfile(DXF_TEMPLATE)

    # Remove existing entities in paperspace
    psp = dxf_doc.paperspace()
    psp.delete_all_entities()
    psp.purge()

    # Remove existing entities in modelspace
    msp = dxf_doc.modelspace()
    msp.delete_all_entities()
    msp.purge()

    total_num_features_written = 0

    for idx in range(num_gpkg_layers):
        layer = gpkg_ds.GetLayer(idx)

        layer_name = layer.GetName()
        logger.info(check_name, 'Export de la couche %s' % layer_name)

        # iterate over layer features
        layer.ResetReading()
        feature = layer.GetNextFeature()
        num_features_read = 0
        num_features_written = 0
        while feature is not None:
            num_features_read += 1

            # get object name
            object_name = feature.GetField('object_name')

            # get object type id
            rep_dwg_ge = feature.GetField('rep_dwg_ge')

            # get dxf layer name and object type for affleurants
            if layer_name in AFFLEURANT_LAYERS:
                reseau = feature.GetField('reseau')
                # get/check dxf layer name
                dxf_layer_name = AFFLEURANT_CALQUE_MAPPING.get(reseau, None)
                if dxf_layer_name is None:
                    logger.warn(check_name,
                                '''L'objet '%s' (couche %s) n'a pas pu être exporté en DXF (reseau '%s' non supporté)''' % (object_name, layer_name, reseau))
                    # move on to next feature
                    feature = layer.GetNextFeature()
                    continue
                elif dxf_layer_name == '':
                    logger.info(check_name,
                                '''L'objet '%s' (couche %s) n'a pas été exporté en DXF (reseau '%s' non exporté en DXF)''' % (object_name, layer_name, reseau))
                    # move on to next feature
                    feature = layer.GetNextFeature()
                    continue
                # get object type
                object_type = AFFLEURANT_OBJECT_TYPE_MAPPING[layer_name]

            # get dxf layer name and object type  for other objects
            else:
                if rep_dwg_ge not in dxf_calques_objets:
                    logger.warn(check_name,
                                '''L'objet '%s' (couche %s) n'a pas pu être exporté en DXF (rep_dwg_ge '%s' non supporté)''' % (object_name, layer_name, rep_dwg_ge))
                    # move on to next feature
                    feature = layer.GetNextFeature()
                    continue

                dxf_layer_name, object_type, alt_attrs, alt_calque = dxf_calques_objets[
                    rep_dwg_ge]

            geom = feature.GetGeometryRef()
            geom_type = geom.GetGeometryType()

            # TODO : handle altitudes (points and attributes)

            if object_type == 'Bloc':
                # geom_type in (ogr.wkbPoint, ogr.wkbPoint25D,) # TODO: check this also ?
                coordinates = geom.GetPoint()
                # add insert
                br = msp.add_blockref(rep_dwg_ge,
                                      coordinates,
                                      dxfattribs={
                                          'layer': dxf_layer_name,
                                          'xscale': 1.0,
                                          'yscale': 1.0,
                                          'rotation': 0.0
                                      })
                # set alt attrs
                alt = coordinates[2]
                # set alt calque
                if alt_calque and alt_calque != 'nc':
                    a = br.add_attrib('ALT',
                                       '%.2f' % alt,
                                      dxfattribs={'layer': alt_calque})
                    a.set_placement(coordinates[:2])
                    a.dxf.width = 1.0
                    a.dxf.height = 0.2
                else:
                    for att in alt_attrs:
                        if att:
                            a = br.add_attrib(att, alt)                            
                # increment num features written
                num_features_written += 1
            elif object_type == 'Point':
                # geom_type in (ogr.wkbPoint, ogr.wkbPoint25D,) # TODO: check this also ?
                coordinates = geom.GetPoint()
                # add point
                msp.add_point(coordinates,
                              dxfattribs={
                                  'layer': dxf_layer_name,
                              })
                num_features_written += 1
            elif object_type == 'Polyligne':
                if geom_type in (ogr.wkbPolygon, ogr.wkbPolygon25D,
                                 ogr.wkbPolygonM, ogr.wkbPolygonZM):
                    coordinates = geom.GetGeometryRef(0).GetPoints()
                else:
                    coordinates = geom.GetPoints()
                # add lwpolyline as it is more lightweight
                msp.add_polyline3d(coordinates,
                                   dxfattribs={
                                       "layer": dxf_layer_name
                                   })
                num_features_written += 1
            elif object_type == 'Hachures':
                if geom_type in (ogr.wkbPolygon, ogr.wkbPolygon25D,
                                 ogr.wkbPolygonM, ogr.wkbPolygonZM):
                    coordinates = geom.GetGeometryRef(0).GetPoints()
                else:
                    coordinates = geom.GetPoints()
                coordinates = geom.GetPoints()
                # add lwpolyline as it is more lightweight
                msp.add_polyline3d(coordinates,
                                   dxfattribs={
                                       "layer": dxf_layer_name
                                   })
                num_features_written += 1
            else:
                logger.error(check_name,
                             '''L'objet '%s' n'a pas pu être exporté en DXF (type d'objet '%s' non supporté)''' % (object_name, layer_name, object_type))

            # move on to next feature
            feature = layer.GetNextFeature()

        logger.info(check_name, 'Nombre objets lus pour la couche %s : %d' % (layer_name,
                                                                              num_features_read))
        logger.info(check_name, 'Nombre objets exportés pour la couche %s : %d' % (layer_name,
                                                                                   num_features_written))

        total_num_features_written += num_features_written

    # Zoom to entities
    zoom.extents(msp)

    # Save DXF file
    dxf_doc.saveas(dxf_filename)

    # Log number of objects exported
    logger.info(check_name, '''Nombre total d'objets exportés : %d''' %
                total_num_features_written)
