###################################################
# Check Socle Commun DXF datasets
###################################################

# Exit when any command fails
set -e

export $(grep -v '^#' paths.env | xargs)

# SDEF

#deliverycheck check-dataset -t referentiel_topographie_geobretagne.sdef.shapefile -p "${DATAPATH}/sdef/combrit/" -o srs EPSG:3948 -o data_type RTS --report-dir ${OUTPUTPATH}/

# deliverycheck check-dataset -t referentiel_topographie_geobretagne.sdef.shapefile -p "${DATAPATH}/sdef/extract" -o srs EPSG:3948 -o data_type RTS --report-dir ${OUTPUTPATH}/

#deliverycheck check-dataset -t referentiel_topographie_geobretagne.sdef.shapefile -p "${DATAPATH}/sdef/territoire-clean2" -o srs EPSG:3948 -o data_type RTS --report-dir ${OUTPUTPATH}/

#deliverycheck check-dataset -t referentiel_topographie_geobretagne.sdef.shapefile -p "${DATAPATH}/sdef/crozon/SHP" -o srs EPSG:3948 -o data_type RTS --report-dir ${OUTPUTPATH}/

deliverycheck check-dataset -t referentiel_topographie_geobretagne.sdef.shapefile -p "${DATAPATH}/sdef/PLOMEUR" -o srs EPSG:3948 -o data_type RTS --report-dir ${OUTPUTPATH}/


